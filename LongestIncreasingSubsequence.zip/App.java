import cars.Car;
import cars.Tesla;
import cars.Toyota;
import catsanddogs.Brutus;
import catsanddogs.Rufus;
import cereals.AbstractCereal;
import cereals.CocoPuffsCereal;
import cereals.SoggyFruitLoopsCereal;
import concurrency.Hare;
import concurrency.Race;
import concurrency.Tortoise;
import dundermifflin.PaperCompany;
import excersizes.ArrayRotation;
import excersizes.LongestIncreasingSubsequence;
import excersizes.OrderStatistics;
import excersizes.OurSinglyLinkedList;
import excersizes.RangeAndMatrix;
import fruits.Kiwi;
import videogames.HalfLife;
import videogames.SciFi;
import videogames.SuperMario;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class App {

    public static void main(String[] args) throws IOException {
    	
    	LongestIncreasingSubsequence longestIncreasingSubsequence = new LongestIncreasingSubsequence();

        Integer[] result = longestIncreasingSubsequence.getLongestIncreasingSubsequence();

        System.out.println("The longest sequence is: ");
        for (Integer i : result) {
            System.out.println(+ i);
        }
        System.out.println("Sequence lenght is: " + result.length);


    }
}